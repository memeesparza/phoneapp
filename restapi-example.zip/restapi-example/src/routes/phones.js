const { Router }= require('express');
const router = Router();
const _ = require('underscore');

const phones = require('../sample.json');
const fs = require('fs');

//routes
router.get('/', (req,res) => {
    res.json(phones);
});

router.get('/:id', (req,res) => {        
    const {id} = req.params;

    _.each(phones,(phone,i) => {
        if(phone.id==id){
            console.log(phone);
            res.json(phone);
        }
    });
});

router.put('/:id', (req,res) => {
    const {id} = req.params;
    console.log(req.body);
    const {name,description,cost,screenSize,screenType,capacity,memoryRAM} = req.body;

    console.log(id);
    if(id)
    {
        _.each(phones,(phone,i) => {
              if(phone.id==id){
                phone.name = name;
                phone.description = description;
                phone.cost = cost;
                phone.screenSize = screenSize;
                phone.screenType = screenType;
                phone.capacity = capacity;
                phone.memoryRAM = memoryRAM;
              }
        });    

        let data = JSON.stringify(phones);
        fs.writeFileSync('../sample.json', data);        
        res.status(200);
    }else{
        res.status(500).json({error:"There was an error"});
    }
});

router.post('/', (req,res) => {
    console.log(req.body);                
    const {name,description,cost,screenSize,screenType,capacity,memoryRAM} = req.body;    
    

    if(name && description && cost && screenSize && screenType && capacity && memoryRAM ){        
        const id = phones.length + 1;
        const newPhone = {...req.body,id};
        phones.push(newPhone);

        let data = JSON.stringify(phones);
        fs.writeFileSync('../sample.json', data);        
        res.send('saved');
    }else{
        res.status(500).json({error:'There was an error.'});
    }    
});

router.delete('/:id', (req,res) => {
    const {id} = req.params;

    if(id){
        _.each(phones,(movie,i) =>{
            if(phone.id == id){
                phones.splice(i,1);
            }
        });
    
        let data = JSON.stringify(phones);
        fs.writeFileSync('../sample.json', data);        
        res.send('deleted');
    }else{
        res.status(500).json({error:'There was an error.'});
    }
    
});

module.exports = router;