const { Router }= require('express');
const router = Router();
const _ = require('underscore');

const phones = require('../sample.json');

//routes
router.get('/', (req,res) => {
    res.json(phones);
});

module.exports = router;