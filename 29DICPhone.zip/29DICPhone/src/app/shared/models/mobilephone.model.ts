// src/app/shared/models/mobilephone.model.ts
import { Feature } from '../models/feature.model';


export class MobilePhone {

  private _id: number;
  private _name: string;
  private _description: string;
  private _specs: string;
  private _cost: number;
  private _screenSize:string;
  private _screenType:string;
  private _capacity:string;
  private _memoryRAM:string;


  get id(): number {
    return this._id;
  }

  set id(value: number) {
    this._id = value;
  }

  get name(): string {
    return this._name;
  }
  set name(value: string) {
    this._name = value;
  }

  get description(): string {
    return this._description;
  }
  set description(value: string) {
    this._description = value;
  }

  get specs(): string {
    return this._specs;
  }
  set specs(value: string) {
    this._specs = value;
  }

  get cost(): number {
    return this._cost;
  }
  set cost(value: number) {
    this._cost = value;
  }

  get screenSize(): string {
    return this._screenSize;
  }
  set screenSize(value: string) {
    this._screenSize = value;
  }

  get screenType(): string {
    return this._screenType;
  }
  set screenType(value: string) {
    this._screenType = value;
  }

  get capacity(): string {
    return this._capacity;
  }

  set capacity(value: string) {
    this._capacity = value;
  }

  get memoryRAM(): string {
    return this._memoryRAM;
  }

  set memoryRAM(value: string) {
    this._memoryRAM = value;
  }

}


