import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-deviceview',
  templateUrl: './deviceview.component.html',
  styleUrls: ['./deviceview.component.css']
})
export class DeviceviewComponent implements OnInit, OnDestroy {
  public productSelected: MobilePhone;
  menu = ['Edit Smartphone', 'Edit Features'];
  Psubscription: Subscription;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute) {

  }

  ngOnInit() {
    let itemid: number;
    itemid =  this.acRoute.snapshot.params['id'];
    this.productSelected = this.deviceService.getItemSelected(itemid);

    this.Psubscription = this.acRoute.params.subscribe(
      (params: Params) => {
         itemid = params['id'];
         this.productSelected = this.deviceService.getItemSelected(itemid);
     }
   );
  }

  ngOnDestroy() {
    this.Psubscription.unsubscribe();
  }


}
