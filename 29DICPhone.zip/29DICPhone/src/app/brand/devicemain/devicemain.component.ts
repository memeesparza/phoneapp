import { Component, OnInit } from '@angular/core';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';
import { DeviceService } from 'src/app/shared/services/Device.service';

@Component({
  selector: 'app-devicemain',
  templateUrl: './devicemain.component.html',
  styleUrls: ['./devicemain.component.css']
})
export class DevicemainComponent implements OnInit {
  showAddDevice = false;
  showEditDevice = false;
  public products: Array<MobilePhone>;

  constructor(private deviceService: DeviceService) {
    this.products = deviceService.products;
  }

  ngOnInit() {
  }

  showDeviceAdd() {
    this.showAddDevice = true;
    this.showEditDevice = false;
  }

  showDeviceEdit() {
    this.showAddDevice = false;
    this.showEditDevice = true;
  }

  onDeviceAdded(deviceData: {name: string}) {

  }

}
