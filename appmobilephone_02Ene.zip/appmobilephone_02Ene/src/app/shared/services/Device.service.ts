import { MobilePhone } from '../models/mobilephone.model';
import { Injectable } from '@angular/core';
import { FeaturesService } from './features.service';
import { Feature } from '../models/feature.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable()
export class DeviceService {

   // Define API
   apiURL = 'http://localhost:3000';

  public products: Array<MobilePhone>;
  public productSelected: MobilePhone;
  public newId = 101;
  public feats: Array<Feature>;
  private url = '/assets/data/employees.json';

  constructor(private featService: FeaturesService, private http: HttpClient) {
    this.products = new Array<MobilePhone>();
    this.productSelected = new MobilePhone();

    let mobile: MobilePhone;
    mobile = new MobilePhone();
    mobile.id = 101;
    mobile.name = 'Iphone 11';
    mobile.description = 'Iphone 11 Apple';
    mobile.cost = 18500;
    this.products.push(mobile);
  }

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

    // GET
    APIGetPhones(): Observable<MobilePhone> {
      console.log(this.apiURL + '/api/phones/');
      return this.http.get<MobilePhone>(this.apiURL + '/api/phones/')
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
    }

    APIGetPhone(phoneId): Observable<MobilePhone> {
      console.log(this.apiURL + '/api/phones/' + phoneId);
      return this.http.get<MobilePhone>(this.apiURL + '/api/phones/' + phoneId)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
    }

    addPhone(data): Observable<MobilePhone> {
      var phoneFormatted = JSON.stringify(data).replace(/[_-]/g, '');

      return this.http.post<MobilePhone>(this.apiURL + '/api/phones/', phoneFormatted, this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
    }

    // Error handling
   errorHandl(error) {
      let errorMessage = '';
      if(error.error instanceof ErrorEvent) {
        // Get client-side error
        errorMessage = error.error.message;
      } else {
        // Get server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      console.log(errorMessage);
      return throwError(errorMessage);
   }

  // getPhones() {
  //   return this.http.get(this.url);
  // }

  getNewKey() {
    this.newId = this.newId + 1;
    return this.newId;
  }


  getItemSelected(selectedId: number) {
    console.log(selectedId);
    this.productSelected = this.products.filter(item => item.id === Number(selectedId))[0];

    return this.productSelected;
  }

  addItem(product: MobilePhone) {
    this.products.push(product);
  }

  updateItem(updatedItem: MobilePhone) {
     let index = this.products.indexOf(updatedItem);
     this.products[index] = updatedItem;
  }

  getFeatures() {
      return this.featService.getFeatures();
  }



}
