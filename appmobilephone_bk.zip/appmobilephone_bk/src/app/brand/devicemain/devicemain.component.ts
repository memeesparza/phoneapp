import { Component, OnInit } from '@angular/core';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';
import { DeviceService } from 'src/app/shared/services/Device.service';

@Component({
  selector: 'app-devicemain',
  templateUrl: './devicemain.component.html',
  styleUrls: ['./devicemain.component.css']
})
export class DevicemainComponent implements OnInit {
  showAddDevice = false;
  showEditDevice = false;
  public products: Array<MobilePhone>;
  IssuesList: any = [];


  constructor(private deviceService: DeviceService) {
    //this.products = deviceService.products;
    this.products = Array<MobilePhone>();
    this.getPhones();

  }

  getPhones() {
    return this.deviceService.APIGetPhones().subscribe((data: {}) => {
      this.IssuesList = data;

      for (var i = 0, len = this.IssuesList.length; i < len; i++) {
        this.products.push(this.IssuesList[i]);
      }
    });
  }

  ngOnInit() {
  }

  showDeviceAdd() {
    this.showAddDevice = true;
    this.showEditDevice = false;
  }

  showDeviceEdit() {
    this.showAddDevice = false;
    this.showEditDevice = true;
  }

  onDeviceAdded(deviceData: {name: string}) {

  }

}
