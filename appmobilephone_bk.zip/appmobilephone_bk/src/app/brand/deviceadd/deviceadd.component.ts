import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { MobilePhone } from '../../shared/models/mobilephone.model';
import {NgForm} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Feature } from 'src/app/shared/models/feature.model';
import { FeaturesService } from 'src/app/shared/services/features.service';

@Component({
  selector: 'app-deviceadd',
  templateUrl: './deviceadd.component.html',
  styleUrls: ['./deviceadd.component.css']
})

export class DeviceaddComponent implements OnInit {
  public product: MobilePhone;
  paramsSubscription: Subscription;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute, private router: Router) {

  }

  ngOnInit() {
  }

  onAddDevice(inputName: HTMLInputElement) {
      console.log('');
  }

  onSubmit(form: NgForm) {
    // validate data

    // call service
    this.product = new MobilePhone();
    this.product.id =  4;
    this.product.name = form.value.name;
    this.product.cost = form.value.cost;
    this.product.description = form.value.description;
    this.product.capacity = form.value.capacity;
    this.product.screenSize = form.value.screenSize;
    this.product.screenType = form.value.screenType;
    this.product.memoryRAM = form.value.memory;

    this.deviceService.addPhone(this.product).subscribe(res => {
      console.log('Issue added!');
    });

    this.router.navigate(['/device']);
  }

}
