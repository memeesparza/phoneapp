import { Component, OnInit, OnDestroy } from '@angular/core';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-deviceview',
  templateUrl: './deviceview.component.html',
  styleUrls: ['./deviceview.component.css']
})
export class DeviceviewComponent implements OnInit, OnDestroy {
  public productSelected: MobilePhone;
  menu = ['Edit Smartphone', 'Edit Features'];
  Psubscription: Subscription;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute) {

  }

  ngOnInit() {
    let itemid: number;
    itemid =  this.acRoute.snapshot.params['id'];
    //this.productSelected = this.deviceService.getItemSelected(itemid);

    this.deviceService.APIGetPhone(itemid).subscribe((data: MobilePhone) => {
      this.productSelected = data;
    });

  //   this.Psubscription = this.acRoute.params.subscribe(
  //     (params: Params) => {

  //        this.deviceService.APIGetPhone(itemid).subscribe((data: {}) => {
  //          console.log(data);
  //         const {name, description, cost, screenSize, screenType, capacity, memoryRAM} = data[0];

  //         this.productSelected = new MobilePhone();
  //         this.productSelected.id = itemid;
  //         this.productSelected.name = name;
  //         this.productSelected.description = description;
  //         this.productSelected.cost = cost;
  //         this.productSelected.screenSize = screenSize;

  //         this.productSelected.screenType = screenType;
  //         this.productSelected.capacity = capacity;
  //         this.productSelected.memoryRAM = memoryRAM;
  //       });
  //    }
  //  );

  }

  ngOnDestroy() {
   // this.Psubscription.unsubscribe();
  }


}
