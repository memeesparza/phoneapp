import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { BrandComponent } from './brand/brand.component';
import { DeviceComponent } from './brand/device/device.component';
import { ProviderComponent } from './provider/provider.component';
import { DeviceaddComponent } from './brand/deviceadd/deviceadd.component';
import { DeviceeditComponent } from './brand/deviceedit/deviceedit.component';
import { TogglemenuDirectiveDirective } from './togglemenu/togglemenu-directive.directive';
import { DeviceService } from './shared/services/Device.service';
import { DeviceviewComponent } from './brand/deviceview/deviceview.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FeaturesComponent } from './features/features.component';
import { DevicemainComponent } from './brand/devicemain/devicemain.component';
import { FeaturesService } from './shared/services/features.service';
import { HttpClientModule } from '@angular/common/http';
import { DevicefeatureaddComponent } from './brand/devicefeatureadd/devicefeatureadd.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/device', pathMatch: 'full' },
  { path: 'device' , component: DevicemainComponent},
  { path: 'deviceadd' , component: DeviceaddComponent },
  {path: 'deviceview/:id', component: DeviceviewComponent},
  {path: 'deviceedit/:id', component: DeviceeditComponent},
  { path: 'devicefeatureadd/:id' , component: DevicefeatureaddComponent },
  { path: 'features' , component: FeaturesComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    BrandComponent,
    DeviceComponent,
    ProviderComponent,
    DeviceaddComponent,
    DeviceeditComponent,
    TogglemenuDirectiveDirective,
    DeviceviewComponent,
    FeaturesComponent,
    DevicemainComponent,
    DevicefeatureaddComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [DeviceService, FeaturesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
