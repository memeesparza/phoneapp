import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeviceaddComponent } from './deviceadd.component';

describe('DeviceaddComponent', () => {
  let component: DeviceaddComponent;
  let fixture: ComponentFixture<DeviceaddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeviceaddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeviceaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
