import { Component, OnInit } from '@angular/core';
import { Feature } from '../shared/models/feature.model';
import { FeaturesService } from '../shared/services/features.service';

@Component({
  selector: 'app-features',
  templateUrl: './features.component.html',
  styleUrls: ['./features.component.css']
})

export class FeaturesComponent implements OnInit {
  public features: Array<Feature>;

  constructor(private featService: FeaturesService) {
      this.features = this.featService.feats;
   }

  ngOnInit() {



  }

}
