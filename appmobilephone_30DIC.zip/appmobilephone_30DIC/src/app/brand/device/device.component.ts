import { Component, OnInit, Input } from '@angular/core';
import { MobilePhone } from '../../shared/models/mobilephone.model';
import { DeviceService } from 'src/app/shared/services/Device.service';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit {
  public products: Array<MobilePhone>;
  @Input('mobile') item: {id:number, name: string, description: string, cost: number,capacity: string, screenSize: string, screenType:string, memoryRAM:string};

  constructor(private deviceService: DeviceService) {

  }

  ngOnInit() {

  }
}
