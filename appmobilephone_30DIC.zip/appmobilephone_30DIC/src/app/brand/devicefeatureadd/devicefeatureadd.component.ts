import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, Validators, FormGroup, FormArray } from '@angular/forms';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';

@Component({
  selector: 'app-devicefeatureadd',
  templateUrl: './devicefeatureadd.component.html',
  styleUrls: ['./devicefeatureadd.component.css']
})

export class DevicefeatureaddComponent implements OnInit {
  public productSelected2: MobilePhone;
  featuresForm: FormGroup;
  private fb: FormBuilder;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute, private router: Router) {
    this.fb = new FormBuilder();

  }

  ngOnInit() {
    let itemid: number;
    itemid = this.acRoute.snapshot.params['id'];
    this.productSelected2 = this.deviceService.getItemSelected(itemid);

    this.featuresForm = this.fb.group({
      name: [this.productSelected2.name, Validators.required],
      description: [this.productSelected2.description, Validators.required],
      cost: [this.productSelected2.cost, Validators.required],
      screenSize: [this.productSelected2.screenSize, Validators.required],
      screenType: [this.productSelected2.screenType, Validators.required],
      capacity: [this.productSelected2.capacity, Validators.required],
      memory: [this.productSelected2.memoryRAM, Validators.required]
    });
  }

  onSubmit(form) {

     this.productSelected2.screenSize = form.value.screenSize;
     this.productSelected2.screenType = form.value.screenType;
     this.productSelected2.capacity = form.value.capacity;
     this.productSelected2.memoryRAM = form.value.memory;
     this.deviceService.updateItem(this.productSelected2);

     this.router.navigate(['/deviceview', this.productSelected2.id]);
  }

}
