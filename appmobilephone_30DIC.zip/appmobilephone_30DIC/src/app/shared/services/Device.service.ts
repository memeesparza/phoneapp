import { MobilePhone } from '../models/mobilephone.model';
import { Injectable } from '@angular/core';
import { FeaturesService } from './features.service';
import { Feature } from '../models/feature.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';


@Injectable()
export class DeviceService {

   // Define API
   apiURL = 'http://localhost:3000';

  public products: Array<MobilePhone>;
  public productSelected: MobilePhone;
  public newId = 101;
  public feats: Array<Feature>;
  private url = '/assets/data/employees.json';

  constructor(private featService: FeaturesService, private http: HttpClient) {
    this.products = new Array<MobilePhone>();
    this.productSelected = new MobilePhone();

    let mobile: MobilePhone;
    mobile = new MobilePhone();
    mobile.id = 101;
    mobile.name = 'Iphone 11';
    mobile.description = 'Iphone 11 Apple';
    mobile.cost = 18500;
    this.products.push(mobile);
  }


  // getPhones() {
  //   return this.http.get(this.url);
  // }

  getNewKey() {
    this.newId = this.newId + 1;
    return this.newId;
  }


  getItemSelected(selectedId: number) {
    console.log(selectedId);
    this.productSelected = this.products.filter(item => item.id === Number(selectedId))[0];

    return this.productSelected;
  }

  addItem(product: MobilePhone) {
    this.products.push(product);
  }

  updateItem(updatedItem: MobilePhone) {
     let index = this.products.indexOf(updatedItem);
     this.products[index] = updatedItem;
  }

  getFeatures() {
      return this.featService.getFeatures();
  }



}
