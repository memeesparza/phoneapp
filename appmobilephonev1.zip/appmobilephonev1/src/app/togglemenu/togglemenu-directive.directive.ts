import { Directive, OnInit,ElementRef, Renderer2, HostBinding } from '@angular/core';

@Directive({
  selector: '[appTogglemenuDirective]'
})
export class TogglemenuDirectiveDirective implements OnInit {

  constructor(private elRef: ElementRef, private renderer: Renderer2) { }

  ngOnInit() {
   this.renderer.addClass(this.elRef.nativeElement, 'nav navbar-nav ml-auto');
  }

}
