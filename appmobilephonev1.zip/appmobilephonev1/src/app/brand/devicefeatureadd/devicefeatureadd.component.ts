import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, Validators , FormGroup, FormArray} from '@angular/forms';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';

@Component({
  selector: 'app-devicefeatureadd',
  templateUrl: './devicefeatureadd.component.html',
  styleUrls: ['./devicefeatureadd.component.css']
})
export class DevicefeatureaddComponent implements OnInit {
  public productSelected2: MobilePhone;
  myForm: FormGroup;
  fb: FormBuilder;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute, private router: Router) {
    this.fb = new FormBuilder();
  }

  ngOnInit() {
     let itemid: number;
     itemid =  this.acRoute.snapshot.params['id'];
     this.productSelected2 = this.deviceService.getItemSelected(itemid);

     this.myForm = this.fb.group({
      question: ['', [Validators.required]],
      features: this.fb.array([
        this.initFeature()
      ]),
      selectedNoOfAttempt: ['', [Validators.required]]
    });

  }

    initFeature() {
      return this.fb.control('', Validators.required);
    }

    addFeature() {
      this.features.push(this.initFeature());
    }

    removeFeature(i: number) {
      this.features.removeAt(i);
    }

   get features(): FormArray {
    return this.myForm.get('features') as FormArray;
  }

  onSubmit(form: NgForm) {

  }

  // onAddFeature(selected: string) {
  //   let html = '';
  //   const element: HTMLElement = document.getElementById('custom') as HTMLElement;

  //   html += '<label>' + selected + '</label>';
  //   html += '<input type="text" id="feature1" name="feature" class="form-control txt-input" ngModel>';

  //   element.innerHTML += html;
  // }

}
