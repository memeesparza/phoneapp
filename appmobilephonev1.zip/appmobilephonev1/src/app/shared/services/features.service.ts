import { Injectable } from '@angular/core';
import { Feature } from '../models/feature.model';

@Injectable()
export class FeaturesService {
  public feats: Array<Feature>;

  constructor() {
    this.feats = new Array<Feature>();

    let feat: Feature;
    feat = new Feature();
    feat.id = 101;
    feat.name = 'Capacity';
    feat.type = 'text';
    feat.defaultv = '64gb';

    this.feats.push(feat);

    feat = new Feature();
    feat.id = 101;
    feat.name = 'Screen';
    feat.type = 'text';
    feat.defaultv = '4.0 inches';

    this.feats.push(feat);
  }

  getFeatures() {
    return this.feats;
  }
}
