import { Component } from '@angular/core';
import { MobilePhone } from './shared/models/mobilephone.model';
import { DeviceService } from './shared/services/Device.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'appmobilephone';

  constructor(private deviceService: DeviceService) {

  }



}
