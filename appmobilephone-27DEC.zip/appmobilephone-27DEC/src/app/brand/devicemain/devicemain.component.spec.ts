import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DevicemainComponent } from './devicemain.component';

describe('DevicemainComponent', () => {
  let component: DevicemainComponent;
  let fixture: ComponentFixture<DevicemainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DevicemainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DevicemainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
