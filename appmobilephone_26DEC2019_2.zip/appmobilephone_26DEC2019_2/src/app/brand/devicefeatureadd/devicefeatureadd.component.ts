import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, Validators, FormGroup, FormArray } from '@angular/forms';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';

@Component({
  selector: 'app-devicefeatureadd',
  templateUrl: './devicefeatureadd.component.html',
  styleUrls: ['./devicefeatureadd.component.css']
})

export class DevicefeatureaddComponent implements OnInit {
  public productSelected2: MobilePhone;
  featuresForm: FormGroup;
  private fb: FormBuilder;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute, private router: Router) {
    this.fb = new FormBuilder();

    this.featuresForm = this.fb.group({
      screen: ['', Validators.required]
    });
  }

  ngOnInit() {
    let itemid: number;
    itemid = this.acRoute.snapshot.params['id'];
    this.productSelected2 = this.deviceService.getItemSelected(itemid);
  }

  onSubmit(form) {

  }

}
