import { Component, OnInit } from '@angular/core';
import { DeviceService } from 'src/app/shared/services/Device.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MobilePhone } from 'src/app/shared/models/mobilephone.model';
import { Subscription } from 'rxjs';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-deviceedit',
  templateUrl: './deviceedit.component.html',
  styleUrls: ['./deviceedit.component.css']
})
export class DeviceeditComponent implements OnInit {
  public productSelected2: MobilePhone;
  menu = ['Edit Smartphone', 'Edit Features'];
  Psubscription: Subscription;

  constructor(private deviceService: DeviceService, private acRoute: ActivatedRoute, private router: Router) {

  }

  ngOnInit() {
    let itemid: number;
    itemid =  this.acRoute.snapshot.params['id'];
    this.productSelected2 = this.deviceService.getItemSelected(itemid);

    this.Psubscription = this.acRoute.params.subscribe(
      (params: Params) => {
         itemid = params['id'];
         this.productSelected2 = this.deviceService.getItemSelected(itemid);
     }
   );
  }

  onSubmit(form: NgForm) {

    this.productSelected2.name = form.value.name;
    this.productSelected2.cost = form.value.cost;
    this.productSelected2.description = form.value.description;
    this.deviceService.updateItem(this.productSelected2);

    this.router.navigate(['/device/view', this.productSelected2.id]);
  }

  onCancel() {
    this.router.navigate(['/device/view', this.productSelected2.id]);
  }

}
